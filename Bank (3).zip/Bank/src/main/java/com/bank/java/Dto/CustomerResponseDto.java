package com.bank.java.Dto;



import lombok.Data;

@Data
public class CustomerResponseDto {
	private Integer customerId;
	private String customerName;
	private String phoneNo;
	private String emailId;
	

}
