package com.bank.java.exception;

public class MyCustomizeedException extends RuntimeException{
	
	public MyCustomizeedException(String message) {
		super(message);
	}

}
