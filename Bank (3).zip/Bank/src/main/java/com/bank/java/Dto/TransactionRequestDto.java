package com.bank.java.Dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class TransactionRequestDto {
	
	@NotNull(message="sender's account id cannot be null")
	private Integer fromAccountId;
	@NotNull(message="reciever's account id cannot be null")
	private Integer toAccountId;
	
	@NotNull(message="amount cannot be null")
	@Min(value=10,message="you cannot send less than 10 rs")
	private Double amount;
	
	@NotEmpty
	private String transactionNumber;

}
