package com.bank.java.Dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class AccountRequestDto {
	
	@NotNull(message="account number cannot be empty")
	private Long accountNumber;
	
	@NotNull(message="balance cannot be empty")
	@Min(value=2000,message="min balance:2000")
	private Double balance;
	@NotNull(message="customer id cannot be empty")
	private Integer customerId;
	@NotEmpty(message="account type cannot be empty")
	private String accountType;
}
