package com.bank.java.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bank.java.Dto.CustomerRequestDto;
import com.bank.java.service.CustomerService;

@ExtendWith(MockitoExtension.class)
public class CustomerControllerTest {

	@Mock
	CustomerService customerService;

	@InjectMocks
	CustomerController customerController;
	CustomerRequestDto customerRequestDto1;
	CustomerRequestDto customerRequestDto;

	@BeforeEach
	public void setUp() {
		customerRequestDto = new CustomerRequestDto();
		customerRequestDto.setCustomerName("prachi");
		customerRequestDto.setPhoneNo("0987634579");
		
		customerRequestDto1 = new CustomerRequestDto();
		customerRequestDto1.setPhoneNo("0987634579534748");
	}

	@Test
	@DisplayName("Save Customer Data  :Positive")
	public void saveCustomerDataTest_Positive() {
//context
		doNothing().when(customerService).saveCustomer(customerRequestDto);
//event
		ResponseEntity<String> result = customerController.saveCustomer(customerRequestDto);

//outcome
		assertEquals("Data Saved Successfully", result.getBody());
		assertEquals(HttpStatus.ACCEPTED, result.getStatusCode());
	}
	
	/*
	 * @Test
	 * 
	 * @DisplayName("Save Customer Data: Negative") public void
	 * saveCustomerDataTest_Negative() { //context //
	 * customerRequestDto1.setPhoneNo("23456789876"); //
	 * doNothing().when(customerService).saveCustomer(customerRequestDto);
	 * 
	 * //event ResponseEntity<String> result =
	 * customerController.saveCustomer(customerRequestDto1);
	 * 
	 * //outcome assertEquals("phone num should be 10 digits", result.getBody());
	 * assertEquals(HttpStatus.NOT_ACCEPTABLE, result.getStatusCode()); }
	 */
	
	
}
	